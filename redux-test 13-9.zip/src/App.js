import React from 'react';
import store from './redux/Store';
import { Provider } from 'react-redux';
import MenuAppBar from './components/appBar/Index';
import ListaColores from './components/listaColores/Index';
import './App.css';

const App = () => (
  <Provider store={store}>
    <div>
      <MenuAppBar></MenuAppBar>   
      <ListaColores></ListaColores>
    </div>
  </Provider>
)



export default App;
