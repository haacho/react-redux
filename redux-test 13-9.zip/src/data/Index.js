const temas = ['love' , 'very-blue', 'orca', 'venice', 'pacific-dream', 'learning', 'celestial', 'purplepine', 'sha-la', 'mini', 'maldives', 'subu'];

export default temas;






