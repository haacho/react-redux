import { combineReducers } from "redux";
import reducerEstablecer from "./EstablecerColor"

export default combineReducers({
    reducerEstablecer
});
