import { createAction } from 'redux-actions';

const updateColor = createAction('updateColor');

export default updateColor;