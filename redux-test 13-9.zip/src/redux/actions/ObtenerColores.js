import { createAction } from 'redux-actions';

const obtenerColores = createAction('obtenerColores');

export default obtenerColores;